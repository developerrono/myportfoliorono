// Similar to admin_restaurants.js, but with an added dropdown to select a restaurant
// Will make AJAX calls to backend/menu_api.php
// Fields: menu_item_id, restaurant_id (from dropdown), name, description, price, availability